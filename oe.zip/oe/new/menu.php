
        <div class="row">           
           
            <div class="col-md-2 portfolio-item">
                <a href="index.php">
                    <img style="height: 50px; width:100px;"class="img-responsive img-thumbnail" src="images/home.png" alt="">
                </a> 
             </div>   
           
            <div class="col-md-2 portfolio-item">
                <a href="subject.php">
                    <img style="height: 50px; width:100px;"class="img-responsive img-thumbnail" src="images/subject.png" alt="">
                </a> 
             </div>   
           
            <div class="col-md-2 portfolio-item">
                <a href="exam.php">
                    <img style="height: 50px; width:100px;"class="img-responsive img-thumbnail" src="images/exam.png" alt="">
                </a> 
             </div>   
           
            <div class="col-md-2 portfolio-item">
                <a href="student.php">
                    <img style="height: 50px; width:100px;"class="img-responsive img-thumbnail" src="images/student.png" alt="">
                </a> 
             </div>   
           
            <div class="col-md-2 portfolio-item">
                <a href="result.php">
                    <img style="height: 50px; width:100px;"class="img-responsive img-thumbnail" src="images/result.png" alt="">
                </a> 
             </div>   
           
            <div class="col-md-2 portfolio-item">
                <a href="logout.php">
                    <img style="height: 50px; width:100px;"class="img-responsive img-thumbnail" src="images/logout.png" alt="">
                </a> 
             </div>    
      </div>