<?php 
session_start();
include("header.php");
//include("menu.php");
include("function.php");

?>
<h1 class="text-red"> Administrator Login </h1>
<?php adminlogin();?> 



<h3 class="">Use of online examination system</h3>
<hr>
<p class=" text-justify">
Today Online Examination System has become a fast growing examination method because of its speed and accuracy. It is also needed less manpower to execute the examination. Almost all organizations now-a-days, are conducting their objective exams by online examination system, it saves students time in examinations. Organizations can also easily check the performance of the student that they give in an examination. As a result of this, organizations are releasing results in less time. It also helps the environment by saving paper.
According to today’s requirement, online examination project in php is very useful to learn it.
</p>


<h3 class="">Online examination system features</h3>
<hr>
<p class=" text-justify">
     <ol>
    <li> Login system must be present and secured by password.</li> 
    <li> Ability to save the answer given by the candidate along with the question.</li> 
    <li> Answer checking system should be available.</li> 
    <li> Could Update Profile</li> 
    <li> Log out after the over.</li> 
    <li> Admin Panel</li> 
    </ol>
</p>



         
 <?php 
include("footer.php");
?>

