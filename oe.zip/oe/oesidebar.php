<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li> 
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Home</a>
                        </li> 
                        <li>
                            <a href="oesubjectlist.php"><i class="fa fa-table fa-fw"></i> Choice Subject for Quiz</a>
                        </li>
                        <li>
                            <a href="forms.html"><i class="fa fa-edit fa-fw"></i> Update Profile</a>
                        </li>
                        <li>
                            <a href="forms.html"><i class="fa fa-tasks fa-fw"></i> Notification</a>
                        </li>
                        <li>
                            <a href="forms.html"><i class="fa fa-table fa-fw"></i> Massage</a>
                        </li>
                        <li>
                            <a href="forms.html"><i class="fa fa-table fa-fw"></i> Scores</a>
                        </li>
                        
                        
                         
                
                        <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i> Other Pages<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="blank.html">Blank Page</a>
                                </li>
                                <li>
                                    <a href="login.html">Login Page</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>